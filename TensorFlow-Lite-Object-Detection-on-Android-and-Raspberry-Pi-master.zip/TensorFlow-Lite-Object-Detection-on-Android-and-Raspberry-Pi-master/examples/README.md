# TensorFlow Lite Object Detection Examples
You've trained a TensorFlow Lite object detection model, but now how do you build an actual program around it? This folder provides code for using TensorFlow Lite object detection models in example applications.

### ChangeCounter.py
